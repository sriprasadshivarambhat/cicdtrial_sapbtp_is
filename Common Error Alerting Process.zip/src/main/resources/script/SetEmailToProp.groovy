import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

//
// Script to check if EmailTo parameter exists, if not set it the default to EmailTo property.
// This property is later used to send the error alert email. 

def Message processData(Message message) {
    
      String newMailTo = message.getProperty("EmailTo")
      if(newMailTo == "") {
          message.setProperty("EmailTo", message.getProperty("DefaultEmailTo"))
      }
      
      
       return message
}