import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

//
// Checking if attachement is oversize
//
def Message processData(Message message) {

    String oversizeAttachment
    if (message.getAttachmentsSize() > message.getProperty("AttachmentSizeLimit")) {
        message.setProperty("OversizeAttachment", "yes")
        oversizeAttachment = "The size of this message payload (" +
                message.getAttachmentsSize() +
                " bytes) is above the maximum allowed (" +
                message.getProperty("AttachmentSizeLimit") +
                " bytes). The payload has been removed."
    } else {
        message.setProperty("OversizeAttachment", "no")
        oversizeAttachment = "Message payload (if sent and allowed) is attached to this email."
    }
    message.setProperty("AttachmentText", oversizeAttachment)

    return message
}