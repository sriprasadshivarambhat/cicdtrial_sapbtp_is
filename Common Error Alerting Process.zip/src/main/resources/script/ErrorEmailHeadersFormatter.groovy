import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

//
// Inserting HTML table to make list of Headers
// more nicely formatted as a text
//
def Message processData(Message message) {
    def hMap = message.getHeaders()
    String headers = "<table>"
    hMap.each {
        headers += "<tr>"
        String line = it
        String hName
        String hValue
        if (line.contains("=") && (line.charAt(line.length()-1) != "=") ) {
            (hName, hValue) = line.split("=")
        } else {
            hName =  line.substring(0,line.length() - 1)
            hValue = ""
        }
        headers += "<td>"
        headers += "<strong>"
        headers += hName
        headers += "</strong>"
        headers += "</td>"
        headers += "<td>"
        if (hName.toLowerCase().contains("authorization") || hName.toLowerCase().contains("token") ) {
            headers += "***"
        } else {
            headers += hValue
        }
        headers += "</td>"
        headers += "</tr>"
    }
    headers += "</table>"
    message.setProperty("Headers", headers)


    return message
}
